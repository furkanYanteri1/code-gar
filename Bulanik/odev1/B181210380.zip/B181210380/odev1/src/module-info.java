module odev1 {
	requires jFuzzyLogic;
}